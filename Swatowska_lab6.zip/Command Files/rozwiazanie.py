# Agata Swatowska
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv('C:/ABD-a/ABD/lab6/Analysis data/14_WIELKOPOLSKIE.csv', sep=',', usecols = ['Dni od zakupu', 'Marka', 'Wiek kupujacego', 'Plec kupujacego', 'Ocena'])
nan_value = float("NaN")
df.replace(["", "bd."], nan_value, inplace=True)
df.dropna(inplace=True)
df['Wiek kupujacego'] = df['Wiek kupujacego'].round(decimals=0).astype(np.int64)

marki = pd.DataFrame({'Marka':sorted(df['Marka'].unique().tolist()),
                     'Wielkopolskie':df.groupby(['Marka']).size().tolist()})

dni_od_zakupu = pd.DataFrame({'Ile dni od zakupu':sorted(df['Dni od zakupu'].unique().tolist()),
                     'Wielkopolskie':df.groupby(['Dni od zakupu']).size().tolist()})

wiek = pd.DataFrame({'Wiek kupujacego':sorted(df['Wiek kupujacego'].unique().tolist()),
                     'Wielkopolskie':df.groupby(['Wiek kupujacego']).size().tolist()})

plec = pd.DataFrame({'Plec kupujacego':sorted(df['Plec kupujacego'].unique().tolist()),
                     'Wielkopolskie':df.groupby(['Plec kupujacego']).size().tolist()})

ocena = pd.DataFrame({'Ocena':sorted(df['Ocena'].unique().tolist()),
                     'Wielkopolskie':df.groupby(['Ocena']).size().tolist()})

# wykres dla marki i dni od zakupu
marki_p = marki[["Marka","Wielkopolskie"]]
dni_p = dni_od_zakupu[["Ile dni od zakupu","Wielkopolskie"]]
marki_p.set_index(["Marka"],inplace=True)
dni_p.set_index(["Ile dni od zakupu"],inplace=True)
fig, ax = plt.subplots(1,2)
fig.set_size_inches(18, 8)
marki_p.plot(ax=ax[0], kind='bar', rot=0)
ax[0].set_ylabel("Liczba wystapien")
ax[0].set_title("Wystapywania marek w wojewodztwie Wielkopolskim")
for p in ax[0].patches:
    ax[0].annotate(np.round(p.get_height(),decimals=2), (p.get_x()+p.get_width()/2., p.get_height()), ha='center', va='center', xytext=(0, 10), textcoords='offset points')
dni_p.plot(ax=ax[1], kind='bar', rot=0)
ax[1].set_ylabel("Liczba wystapien")
ax[1].set_title("Porównanie ilości ocen wystawionych w danym czasie od zakupu")
for p in ax[1].patches:
    ax[1].annotate(np.round(p.get_height(),decimals=2), (p.get_x()+p.get_width()/2., p.get_height()), ha='center', va='center', xytext=(0, 10), textcoords='offset points')

# wykres dla wieku kupujacych
wiek_p = wiek[["Wiek kupujacego","Wielkopolskie"]]
plec_p = plec[["Plec kupujacego","Wielkopolskie"]]
plec_p.set_index(["Plec kupujacego"],inplace=True)
wiek_p.set_index(["Wiek kupujacego"],inplace=True)
fig2, ax2 = plt.subplots()
fig2.set_size_inches(16, 8)
wiek_p.plot(ax=ax2, kind='bar', rot=0)
ax2.set_ylabel("Liczba wystapien")
ax2.set_title("Porownanie liczby kupujacych w danym wieku")
for p in ax2.patches:
    ax2.annotate(np.round(p.get_height(),decimals=2), (p.get_x()+p.get_width()/2., p.get_height()), ha='center', va='center', xytext=(0, 10), textcoords='offset points')

# wykres dla plci kupujacych i oecny
plec_p = plec[["Plec kupujacego","Wielkopolskie"]]
plec_p.set_index(["Plec kupujacego"],inplace=True)
ocena_p = ocena[["Ocena","Wielkopolskie"]]
ocena_p.set_index(["Ocena"],inplace=True)
fig3, ax3 = plt.subplots(1,2)
fig3.set_size_inches(18, 8)
plec_p.plot(ax=ax3[0], kind='bar', rot=0)
ax3[0].set_ylabel("Liczba wystapien")
ax3[0].set_title("Porównanie ilości ocen wystawionych w danym czasie od zakupu")
for p in ax3[0].patches:
    ax3[0].annotate(np.round(p.get_height(),decimals=2), (p.get_x()+p.get_width()/2., p.get_height()), ha='center', va='center', xytext=(0, 10), textcoords='offset points')
ocena_p.plot(ax=ax3[1], kind='bar', rot=0)
ax3[1].set_ylabel("Liczba wystapien")
ax3[1].set_title("Porównanie liczby wystapien poszczegolnych ocen")
for p in ax3[1].patches:
    ax3[1].annotate(np.round(p.get_height(),decimals=2), (p.get_x()+p.get_width()/2., p.get_height()), ha='center', va='center', xytext=(0, 10), textcoords='offset points')


# Dodatkowe1: Ile osob w wieku 30-50 kupilo odkurzacz marki Beko
dod1 = df.loc[((df['Wiek kupujacego'] >= 30) & (df['Wiek kupujacego'] <= 50)) & (df['Marka'] == 'Beko')]
dod1_df = pd.DataFrame({'Wiek':sorted(dod1['Wiek kupujacego'].unique().tolist()),
                        'Liczba wystapien':dod1.groupby(['Wiek kupujacego']).size().tolist()})
dod1_p = dod1_df[["Wiek","Liczba wystapien"]]
dod1_p.set_index(["Wiek"],inplace=True)
fig4, ax4 = plt.subplots()
fig4.set_size_inches(12, 8)
dod1_p.plot(ax=ax4, kind='bar', rot=0)
ax4.set_ylabel("Liczba wystapien")
ax4.set_title("Przedstawienie liczby osób w wieku 30-50, ktore kupily odkurzacz marki Beko")
for p in ax4.patches:
    ax4.annotate(np.round(p.get_height(),decimals=2), (p.get_x()+p.get_width()/2., p.get_height()), ha='center', va='center', xytext=(0, 10), textcoords='offset points')

# Dodatkowe2: Srednia ilosc dni od zakupu osob, ktore wystawily ocene 5 po zakupie odkurzacza marki Electrolux
dod2 = df.loc[(df['Marka'] == 'Electrolux') & (df['Ocena'] == 5)]
rozw_dod2 = dod2['Dni od zakupu'].mean()
print('Odpowiedz do zadania dodatkowego nr 2')
print("Srednia ilosc dni od zakupu osob, ktore wystawily ocene 5 po zakupie odkurzacza marki Electrolux: {:.1f}".format(rozw_dod2))
print("Dla porownania, srednia ilosc dni od zakupu: {:.1f}".format(df['Dni od zakupu'].mean()))

# dodatkowe3: W jakim wieku mezczyzni kupuja odkurzacze marki Samsung
dod3 = df.loc[(df['Marka'] == 'Samsung') & (df['Plec kupujacego'] == 'M')]
dod3_df = pd.DataFrame({'Wiek':sorted(dod3['Wiek kupujacego'].unique().tolist()),
                        'Liczba wystapien':dod3.groupby(['Wiek kupujacego']).size().tolist()})
dod3_p = dod3_df[["Wiek","Liczba wystapien"]]
dod3_p.set_index(["Wiek"],inplace=True)
fig5, ax5 = plt.subplots()
fig5.set_size_inches(12, 8)
dod3_p.plot(ax=ax5, kind='bar', rot=0)
ax5.set_ylabel("Liczba wystapien")
ax5.set_title("Przedstawienie w jakim wieku mezczyzni kupuja odkurzacze marki Samsung")
for p in ax5.patches:
    ax5.annotate(np.round(p.get_height(),decimals=2), (p.get_x()+p.get_width()/2., p.get_height()), ha='center', va='center', xytext=(0, 10), textcoords='offset points')

fig.savefig('C:/ABD-a/ABD/lab6/Analysis data/marki_dni_wykres.png')
fig2.savefig('C:/ABD-a/ABD/lab6/Analysis data/wiek_wykres.png')
fig3.savefig('C:/ABD-a/ABD/lab6/Analysis data/plec_ocena_wykres.png')
fig4.savefig('C:/ABD-a/ABD/lab6/Analysis data/dod1_wykres.png')
fig5.savefig('C:/ABD-a/ABD/lab6/Analysis data/dod3_wykres.png')
