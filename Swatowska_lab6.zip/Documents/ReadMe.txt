Agata Swatowska
Cwiczenie 5
->Zadanie: Zgodnie z zaleceniami protokolu TIER nalezy:
*opisac kazda ze zmiennych
*przygotowac wykres (histogram albo slupkowy) dla kazdej ze zmiennych. Określic w odpowiedni sposob wartosc binsdla kazdej ze zmiennych
*zastosowac odpowiednia strukture plikow
Suma liczby liter imiona i nazwiska (Agata Swatowska) -> 14, reszta z dzielienia przez 16 to również 14, 
więc analizowany będzie zestaw 14_WIELKOPOLSKIE.csv

Rozwiazanie:
1. Dla ułatwienia zadania, ręcznie zmieniono nazwy plików oraz rekordy, które posiadały znaki polskie (aby już ich nie posiadały).
2. W dalszej analizie użyto już obrobionych plików, które można zanleźć w folderze Analysis Data.
3. Wczytano dane do struktur data frame (pominięto kolumne indeksowom) z pliku 14_WIELKOPOLSKIE.csv
4. Aby poprawić przejrzystość danych, usunięto wszystkie rekordy błednie wypełnione (zawierające puste komórki lub z wartością bd.)
5. Wartości w kolumnie 'Wiek kupujacego' zaokrąglono do jednostek i zmieniono typ z float na int64, również dla przjerzystości danych.
6. Aby przestawić wszystkie zmienne (kolumny), wczytano je do osobnych struktór: 'marki', 'dni_od_zakupu', 'wiek', 'plec', 'ocena'.
   Pierwsza kolumna to unikatowe wartości dla danej zmiennej, druga to liczba ich występowania w bazie.
7. Wykresy dla zmiennych:
	- Marki oraz dni od zakupu przedstawiono na wykresach w jednym pliku: marki_dni_wykres.png
	- Wykres wieku kupujących został zapisany w pliku: wiek_wykres.png
	- Wykresy przestawiające płeć kupujących oraz oceny przez nich wystawione jest w pliku plec_ocena_wykres.png
8. Użyto wykresów słupkowych (bar), dla lepszej przejrzystości dodano zapis liczbowy wartości z osi Y nad słupkami danych (ax.annotate)

***** Dodatkowo, wykonano trzy zadania statystyczne (wybrane własnoręcznie) (głownie użyto tu funkcji loc oraz mean)
I ->  Ile osób w wieku 30-50 kupiło odkurzacz marki Beko (odpowiedź w postaci wykresu, w pliku dod1_wykres.png)
II -> Dodatkowe2: Srednia ilosc dni od zakupu osob, ktore wystawily ocene 5 po zakupie odkurzacza marki Electrolux 
      Odpowiedź z konsoli (wyświetla się po puszczeniu (run) pliku rozwiazanie.py): 
	"Odpowiedz do zadania dodatkowego nr 2
	Srednia ilosc dni od zakupu osob, ktore wystawily ocene 5 po zakupie odkurzacza marki Electrolux: 6.8
	Dla porownania, srednia ilosc dni od zakupu: 7.3"
III -> W jakim wieku meżczyźni kupują odkurzacze marki Samsung (odpowiedź w postaci wykresu, w pliku dod3_wykres.png)
	
